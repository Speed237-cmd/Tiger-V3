No copyright 

bug bot by Mickey mods 
message me here if there's any issue 👉 wa.me/+237651707126

